# HomunculAi — Press Kit

*A desktop avatar for the AI you already use. Free for Windows.*

---

## Fact Sheet

| | |
|---|---|
| **Product** | HomunculAi |
| **Developer** | KrookedLilly (Jennifer Green & Ryan Harrington) |
| **Platform** | Windows |
| **Release date** | [update release date] (original launch: April 17, 2026) |
| **Cost** | Free. No account, no email, no payment. |
| **Age** | 18+ (HomunculAi is not for children; see the Terms). Some regions are excluded; see "Download Restrictions" on the website. |
| **Distribution** | [krookedlilly.com](https://www.krookedlilly.com/apps/homunculai), or direct download from [github.com/KrookedLilly/homunculai-releases](https://github.com/KrookedLilly/homunculai-releases/releases). |
| **Works with** | Apps that can run a local MCP server. One-click setup for Claude Desktop, Claude Code, Cursor, VS Code and Windsurf. Other MCP apps take a short manual step. HomunculAi is an independent app by KrookedLilly. It is not affiliated with or endorsed by the makers of these apps; product names belong to their owners. |
| **Styles** | Three, 24 bodies each: Playful, Sleek, Pixel. |
| **Website** | [krookedlilly.com/apps/homunculai](https://www.krookedlilly.com/apps/homunculai) |
| **Press contact** | Jennifer Green, homunculai@krookedlilly.com |

---

## Short description

HomunculAi is a free Windows app: a desktop avatar for the AI you already use. Your AI picks its form, colors and expression, and can show when it's working, has a question, is waiting for you, is done or is stuck. No AI inside. Works with Claude Desktop, Claude Code, Cursor, VS Code, Windsurf and other MCP apps.

---

## Medium description

HomunculAi is a desktop avatar for the AI you already use. You install it and pick a style: Playful, Sleek or Pixel. You connect your AI app in one click, then ask your AI to join. It picks its own body, colors, accessories and expression, and can show whether it's working, has a question, is waiting for you, is done or is stuck. No AI lives inside HomunculAi; it draws only what the AI you connect asks for. Free for Windows.

---

## Long description

HomunculAi is a small transparent window that floats on top of whatever you're working on: your editor, your design software, your browser. When your AI joins, it picks how it looks there. Sometimes a dragon in a top hat, sometimes a pixel toaster in a monocle, sometimes a muted orb that takes itself very seriously. The AI picks the form, the colors, the accessories and the expression, and can show whether it's working, has a question, is waiting for you, is done or is stuck, so you can tell at a glance without switching windows.

You pick the style. Your AI picks the rest. Playful is drawn characters with outlines and some bounce. Sleek is simple abstract shapes with a two-bar face, muted colors and calm motion. Pixel is grid sprites with bold pixel faces. Each style has 24 bodies and the same vocabulary of expression; only the drawing differs. You can change style while an AI is connected, and the AI then picks a new body.

HomunculAi contains no AI. It has no model and generates nothing. Every decision about the body, the expression and the words in the speech and thought bubbles comes from the MCP app you've connected. HomunculAi gives that app a set of tools for showing itself on screen, and it draws whatever the app asks for.

It works with apps that can run a local Model Context Protocol (MCP) server. Setup is one click for Claude Desktop, Claude Code, Cursor, VS Code and Windsurf, and a short manual step for other MCP apps.

Your AI isn't running all the time. It checks in when you write to it in your AI app, or on a check-in loop if your app can run one. Between check-ins the avatar keeps its last look. After a quiet while it dims and can show when your AI last checked in.

KrookedLilly is a husband-and-wife indie studio. HomunculAi is their take on a simple question: if your AI could show body language, what would that look like? The answer is different for every AI, and that has been the best part of making it.

---

## How it works

1. Install HomunculAi and pick a style.
2. Connect your AI app in one click.
3. Ask your AI to join. It picks a body, then updates the avatar each time it checks in: whenever you write to it, or every few minutes on a check-in loop if your app can run one.

Your AI isn't running all the time. It checks in when you write to it in your AI app, or on a check-in loop. Between check-ins the avatar keeps its last look.

---

## Feature list

- **Three styles, 24 bodies each.** Playful, Sleek and Pixel. You pick the style; your AI picks the body, colors and accessories.
- **Work states.** working, has a question, waiting for you, done and stuck. Your AI can show them with its face, calm motion, a small mark and a word on the name plate.
- **A wide vocabulary.** 29 expressions, 19 gestures, 30 emotes, 15 quick reactions, 22 effects, 20 idle motions and 36 accessories (25 worn, 11 held), plus speech bubbles and thought bubbles.
- **It draws its own body.** Once you verify your AI (the shield icon on the name plate), it can draw its own body or layers as SVG. The drawing is sanitized: no scripts, no outside resources, no fast flashing.
- **MCP-native.** One-click setup for Claude Desktop, Claude Code, Cursor, VS Code and Windsurf; other MCP apps by a short manual step.
- **Activity log.** It shows what your AI does, and wording worth a second look is flagged.
- **Pause any time.** Pause stops the avatar immediately, and the app enforces it. Auto-disconnect after a quiet period you choose.
- **Several avatars.** One AI per avatar; several AI apps can each have their own avatar at once.
- **Dims while idle.** After a quiet while the avatar dims and can show when your AI last checked in, with a link to open your AI app when your computer can open it.
- **A few short sounds.** The app can play a short sound when your AI arrives or leaves, finishes a stretch of work, has a question or gets stuck, and for a high-priority flag; high-priority flags also get a desktop notification. Mute one avatar or all of them in Settings.
- **Transparent desktop window.** Sits on top of whatever you're working on without taking over the screen.
- **No account required.** Free to download and use. No telemetry.

---

## Security & privacy

HomunculAi runs on the user's machine. No telemetry, no tracking, no account. HomunculAi itself goes online only to check for updates and, if you choose, to download one (from GitHub). It checks when you select "Check for updates" in Settings, or each time it starts if you allow that. It asks once, at first launch. "Send feedback" opens a Google Form in your browser. The connected AI app is a separate vendor with its own privacy policy.

- **No AI in the app itself.** HomunculAi generates nothing. All text and visuals come from the user's MCP app.
- **An activity log you can read.** An activity log shows what the AI does and marks wording worth a second look. The human decides what it means.
- **Honest identity.** The name plate shows "This is an AI agent, not a human." when an AI connects, and again every few hours.
- **Visual sandboxing.** An AI can't draw its own body or hide built-in visuals until you verify it. Drawings are sanitized for scripts, outside resources and fast flashing; text that imitates app prompts is flagged, and drawings are clipped to the avatar's box.
- **Session integrity.** One AI per avatar, and if a second chat in the same app asks for its own avatar, you are asked to Allow or Deny. Pause is enforced by the app, not requested of the AI.
- **Tamper-evident audit log.** A local audit trail uses a hash chain to detect edits. It holds no full message text (a flag can quote the word that raised it), you can turn it off in Settings, and it stays on your computer.

---

## About KrookedLilly

KrookedLilly is an indie studio run by Jennifer Green and Ryan Harrington, a husband-and-wife team building whatever catches their attention at the time. More at [krookedlilly.com](https://www.krookedlilly.com).

---

## Asset inventory

Curated selection of the assets most useful for press coverage. Additional variants available on request. All avatars in these assets are drawn by the app's own renderer.

**Logos** (`logos/`)
- `logos/logo-homunculai.svg` and `logos/logo-homunculai.png`: logomark / icon only (from the app icon files `icon.svg` and `icon.png`)
- `logos/logo-type-homunculai.svg` and `logos/logo-type-homunculai.png`: full wordmark (icon + typography), vector and PNG with transparency (from `logo-type-homunculai.svg` and `logo-type.png`)

**Marketing key art** (`key-art/`)
- `hero-homunculai.png` (and `hero-homunculai@2x.png`): primary wide marketing image with wordmark, all three styles and tagline. Recommended lead image for articles (1232×706; 2464×1412 @2x).
- `banner-homunculai-wide.png`: ultra-wide banner, no wordmark, for outlets that want to overlay their own headline (3840×1240).
- `capsule-homunculai-vertical.png`: vertical/portrait marketing image for thumbnails and sidebar slots (748×896).
- `library-capsule.png`: portrait catalog image (600×900).
- `homunculai-og.png`: link-preview image (1200×630).
- `youtube-thumbnail.png`: 1280×720.

**In-app screenshots** (`screenshots/`) *(unframed, preferred for press use, journalists can comp their own; 1920×1080)*
- `code-screenshot.png`: an avatar over an editor, developer workflow use case
- `art-screenshot.png`: an avatar over a design canvas, creative workflow use case
- `multiavatar-screenshot.png`: three styles at once
- `work-states-screenshot.png`: an AI waiting for you over a code editor, asking a question (the five work states, one avatar each, across the three styles: `social/s09-work-states.png`)
- `svg-screenshot.png`: a verified AI showing its own drawn body, with the verification mark visible
- `settings-look-screenshot.png`: the style picker in Settings (Look)
- `log-screenshot.png`: the activity log
- `transparent/`: each window alone, with transparency

**Stylized marketing screenshots** (`screenshots-stylized/`) *(pre-framed fallbacks for outlets that want ready-made visuals; same subjects as the raw set)*
- `code-screenshot-styled.png`, `art-screenshot-styled.png`, `multiavatar-screenshot-styled.png`, `work-states-screenshot-styled.png`, `svg-screenshot-styled.png`, `settings-look-screenshot-styled.png`, `log-screenshot-styled.png`

**Social images** (`social/`)
- `s01-launch-square.png`, `s02-launch-landscape.png`, `s03-launch-portrait.png`, `s04-story.png`: launch art in four shapes
- `s05-three-styles.png`: Playful, Sleek and Pixel side by side
- `s06-lineup-playful.png`, `s06-lineup-sleek.png`, `s06-lineup-pixel.png`: all 24 bodies of each style
- `s07-expressions.png`: nine expressions, three in each style
- `s08-dress-up.png`: six looks your AI could pick, with accessories
- `s09-work-states.png`: the five work states, one avatar each, across the three styles
- `s10-no-ai-inside.png`: the trust card

**Founders photo** (`founders-photo.jpg`)
- Jennifer Green and Ryan Harrington, 2400×1600 JPEG

**Video** (`video/`)
- `reel-master-16x9.mp4`: 52-second demo with voice-over, 1920×1080, H.264 web-optimized, captioned
- `reel-master-16x9-clean.mp4`: the same without captions, for editors
- `reel-hero-30s.mp4`: 30-second cut, 1920×1080
- `reel-vertical-15s.mp4`: 15-second vertical cut (1080×1920) for Reels, Shorts and TikTok coverage
- `loop-6s.mp4` and `loop-6s.gif`: 6-second inline loop for article embeds and email
- The press-kit videos have no background music: voice-over and the app's own sounds only (the loop is silent).
- YouTube: [new YouTube link]
- Also available on request: square and vertical 30-second cuts, and short single-idea clips (arrival, work states, styles, dress-up, expressions, drawing its own body, check-ins) in square and vertical.

**Available on request**
- Review access and walkthroughs
- Additional in-app screenshots
- Developer photos
- High-resolution variants of any asset

---

## Contact

**Press inquiries:**
Jennifer Green
homunculai@krookedlilly.com

Happy to answer press questions over email, typically turned around in 1–2 business days.

---

*Press kit last updated November 2026.*
